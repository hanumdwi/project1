<?php $__env->startSection('title', 'categories'); ?>

<?php $__env->startSection('container'); ?>

	<title>Edit Data category</title>
</head>
<body>
 
<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title"><strong>Edit Data category</strong></h3>
            <ul class="panel-controls">
                <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
            </ul>
    </div>
               <div class="panel-body">                                                                        
                <div class="row">
                    <div class="col-md-6">
 
	<a href="categorycreate"> Kembali</a>
	
	<br/>
	<br/>
 
	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<form action="categoriesupdate" method="post">
		<?php echo e(csrf_field()); ?>


		<input type="hidden" name="id" value="<?php echo e($c->category_id); ?>"> <br/>
        <div class="form-group">
        <label class="col-md-3 control-label">Category Name</label>
        <div class="col-md-9">                                            
            <div class="input-group">
                <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                    <input type="text" class="form-control" id="category_name" name="category_name" value="<?php echo e($c->category_name); ?>"><br/></div>                                            
                        <span class="help-block"></span>
                            </div>
                                </div>

		<button type="submit" class="btn btn-info mt-3">Simpan Data</button>
	</form>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cobalaravel\resources\views/master/categories/edit.blade.php ENDPATH**/ ?>